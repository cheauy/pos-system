"use client";

import { useActionState, useEffect, useRef } from "react";
import { toast } from "sonner";

import ImageUpload from "@/components/image-upload";
import { getProductExperience } from "@/lib/business/product-experience";
import {
  createProduct,
  type CreateProductState,
} from "./actions";

type Category = {
  id: string;
  name: string;
};

const initialState: CreateProductState = {
  success: false,
  message: "",
};

export default function StandardProductForm({
  categories, branches=[],
  businessType = "general",
  generalShop = false,
  onCreated,
}: {
  categories: Category[]; branches?:{id:string;name:string}[];
  businessType?: string;
  generalShop?: boolean;
  onCreated?: () => void;
}) {
  const formRef = useRef<HTMLFormElement>(null);
  const experience = getProductExperience(businessType).standard ?? getProductExperience("general").standard!;

  const [state, formAction, pending] =
    useActionState(createProduct, initialState);

  useEffect(() => {
    if (!state.message) return;

    if (state.success) {
      toast.success(state.message);
      formRef.current?.reset();
      onCreated?.();
    } else {
      toast.error(state.message);
    }
  }, [state, onCreated]);

  return (
    <form
      ref={formRef}
      action={formAction}
      className="mt-6 space-y-5"
    >
      <label className="block text-sm font-semibold text-slate-700">Assign to Branch<select name="locationId" required defaultValue={branches[0]?.id||""} className="mt-2 w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5"><option value="" disabled>Choose branch</option>{branches.map(b=><option key={b.id} value={b.id}>{b.name}</option>)}</select></label>
      <div className="rounded-2xl border border-blue-100 bg-blue-50/60 p-4 text-sm text-slate-700">
        <p className="font-semibold text-slate-900">{getProductExperience(businessType).modeLabel}</p>
        <p className="mt-1 text-xs leading-5 text-slate-600">{experience.helper}</p>
      </div>

      <div>
        <label
          htmlFor="name"
          className="mb-2 block text-sm font-medium text-slate-700"
        >
          {experience.nameLabel}
        </label>

        <input
          id="name"
          name="name"
          type="text"
          required
          minLength={2}
          placeholder={experience.namePlaceholder}
          className={inputClass}
        />
      </div>

      <div>
        <label
          htmlFor="categoryId"
          className="mb-2 block text-sm font-medium text-slate-700"
        >
          Category
        </label>

        <select
          id="categoryId"
          name="categoryId"
          defaultValue=""
          className={inputClass}
        >
          <option value="">No category</option>

          {categories.map((category) => (
            <option
              key={category.id}
              value={category.id}
            >
              {category.name}
            </option>
          ))}
        </select>
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        <div>
          <label
            htmlFor="sku"
            className="mb-2 block text-sm font-medium text-slate-700"
          >
            SKU
          </label>

          <input
            id="sku"
            name="sku"
            type="text"
            required
            placeholder={experience.skuPlaceholder}
            className={inputClass}
          />
        </div>

        {generalShop ? (
          <div>
            <label htmlFor="barcode" className="mb-2 block text-sm font-medium text-slate-700">
              Barcode <span className="font-normal text-slate-400">(optional)</span>
            </label>
            <input
              id="barcode"
              name="barcode"
              type="text"
              placeholder="Scan or enter barcode"
              className={inputClass}
            />
            <p className="mt-1.5 text-[11px] text-slate-400">If empty, SKU is used as the barcode.</p>
          </div>
        ) : (
          <ImageUpload />
        )}
      </div>

      {generalShop && (
        <>
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label htmlFor="color" className="mb-2 block text-sm font-medium text-slate-700">
                Color <span className="font-normal text-slate-400">(optional)</span>
              </label>
              <input id="color" name="color" type="text" placeholder="Black, Blue, Clear..." className={inputClass} />
            </div>
            <div>
              <label htmlFor="size" className="mb-2 block text-sm font-medium text-slate-700">
                Size / option <span className="font-normal text-slate-400">(optional)</span>
              </label>
              <input id="size" name="size" type="text" placeholder="500ml, 128GB, Large..." className={inputClass} />
            </div>
          </div>
          <ImageUpload />
        </>
      )}

      <div className="grid gap-4 sm:grid-cols-2">
        <div>
          <label
            htmlFor="costPrice"
            className="mb-2 block text-sm font-medium text-slate-700"
          >
            Cost price
          </label>

          <input
            id="costPrice"
            name="costPrice"
            type="number"
            required
            min="0"
            step="0.01"
            defaultValue="0"
            className={inputClass}
          />
        </div>

        <div>
          <label
            htmlFor="sellingPrice"
            className="mb-2 block text-sm font-medium text-slate-700"
          >
            Selling price
          </label>

          <input
            id="sellingPrice"
            name="sellingPrice"
            type="number"
            required
            min="0"
            step="0.01"
            defaultValue="0"
            className={inputClass}
          />
        </div>
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        <div>
          <label
            htmlFor="stockQuantity"
            className="mb-2 block text-sm font-medium text-slate-700"
          >
            {experience.stockLabel}
          </label>

          <input
            id="stockQuantity"
            name="stockQuantity"
            type="number"
            required
            min="0"
            step="1"
            defaultValue="0"
            className={inputClass}
          />
        </div>

        <div>
          <label
            htmlFor="lowStockQuantity"
            className="mb-2 block text-sm font-medium text-slate-700"
          >
            Low-stock alert
          </label>

          <input
            id="lowStockQuantity"
            name="lowStockQuantity"
            type="number"
            required
            min="0"
            step="1"
            defaultValue="5"
            className={inputClass}
          />
        </div>
      </div>

      {generalShop && (
        <label className="flex items-start gap-3 rounded-xl border border-slate-200 bg-slate-50 px-4 py-3">
          <input
            type="checkbox"
            name="isOnline"
            defaultChecked
            className="mt-0.5 h-4 w-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
          />
          <span>
            <span className="block text-sm font-semibold text-slate-800">Show on online store</span>
            <span className="mt-0.5 block text-xs leading-5 text-slate-500">Customers can see this product on your public store while it remains active.</span>
          </span>
        </label>
      )}

      <div>
        <label
          htmlFor="description"
          className="mb-2 block text-sm font-medium text-slate-700"
        >
          Description
        </label>

        <textarea
          id="description"
          name="description"
          rows={3}
          placeholder={experience.descriptionPlaceholder}
          className={`${inputClass} resize-none`}
        />
      </div>

      <button
        type="submit"
        disabled={pending}
        className="w-full rounded-xl bg-blue-600 px-4 py-3 font-semibold text-white transition hover:bg-blue-700 disabled:cursor-not-allowed disabled:opacity-60"
      >
        {pending ? "Adding product..." : experience.buttonLabel}
      </button>
    </form>
  );
}

const inputClass =
  "w-full rounded-xl border border-slate-300 px-4 py-3 text-slate-900 outline-none transition focus:border-blue-500 focus:ring-4 focus:ring-blue-100";