'use client';

import { useEffect, useMemo, useState } from 'react';
import { Check, RotateCcw, Save, ShieldCheck } from 'lucide-react';
import {
  editablePermissionRoles,
  permissionGroups,
  permissionLabels,
  permissionDescriptions,
  rolePermissions,
  normalizePermissionSelection,
  removePermissionWithDependents,
  type EditablePermissionRole,
  type Permission,
} from '@/lib/auth/permissions';
import type { BusinessRole } from '@/lib/business/types';
import { TEAM_ROLE_LABELS } from '@/lib/users/team-model';
import { resetRolePermissions, saveRolePermissions } from './users-workspace-actions';

type Props = {
  businessId: string;
  actorRole: BusinessRole;
  matrix: Record<BusinessRole, Permission[]>;
  onChange: (role: EditablePermissionRole, permissions: Permission[]) => void;
};

export default function RolePermissionsEditor({ businessId, actorRole, matrix, onChange }: Props) {
  const [role, setRole] = useState<EditablePermissionRole>('manager');
  const [selected, setSelected] = useState<Permission[]>(matrix.manager ?? rolePermissions.manager);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<{ error: boolean; text: string } | null>(null);
  const editable = actorRole === 'owner';

  useEffect(() => {
    setSelected([...(matrix[role] ?? rolePermissions[role])]);
    setMessage(null);
  }, [matrix, role]);

  const selectedSet = useMemo(() => new Set(selected), [selected]);
  const saved = matrix[role] ?? rolePermissions[role];
  const dirty = useMemo(() => {
    const current = new Set(selected);
    const baseline = new Set(saved);
    return current.size !== baseline.size || [...current].some((permission) => !baseline.has(permission));
  }, [saved, selected]);

  function toggle(permission: Permission) {
    if (!editable || busy) return;
    setSelected((current) =>
      current.includes(permission)
        ? removePermissionWithDependents(current, permission)
        : normalizePermissionSelection([...current, permission]),
    );
  }

  async function save() {
    if (!editable || busy) return;
    setBusy(true);
    setMessage(null);
    try {
      const result = await saveRolePermissions(businessId, role, selected);
      if (!result.success) {
        setMessage({ error: true, text: result.message });
        return;
      }
      setSelected(result.data.permissions);
      onChange(result.data.role, result.data.permissions);
      setMessage({ error: false, text: result.message });
    } catch {
      setMessage({ error: true, text: 'Permission save could not be confirmed. Refresh before trying again.' });
    } finally {
      setBusy(false);
    }
  }

  async function reset() {
    if (!editable || busy) return;
    if (!window.confirm(`Reset ${TEAM_ROLE_LABELS[role]} to the TENH default permissions?`)) return;
    setBusy(true);
    setMessage(null);
    try {
      const result = await resetRolePermissions(businessId, role);
      if (!result.success) {
        setMessage({ error: true, text: result.message });
        return;
      }
      setSelected(result.data.permissions);
      onChange(result.data.role, result.data.permissions);
      setMessage({ error: false, text: result.message });
    } catch {
      setMessage({ error: true, text: 'Permission reset could not be confirmed. Refresh before trying again.' });
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="space-y-5">
      <div className="rounded-2xl border border-blue-100 bg-blue-50 p-4 text-sm text-blue-900">
        <div className="flex items-start gap-3">
          <ShieldCheck className="mt-0.5 shrink-0 text-blue-600" size={20} />
          <div>
            <p className="font-semibold">Owner always keeps full access.</p>
            <p className="mt-1 text-blue-700">
              Choose a role and tick the features that role is allowed to use. TENH shows friendly feature names only. Disabled features are removed from supported menus and actions, and server checks still block direct access. Required supporting access is added automatically when a selected feature depends on it.
            </p>
          </div>
        </div>
      </div>

      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap gap-2" role="tablist" aria-label="Role permissions">
        {editablePermissionRoles.map((value) => (
          <button
            key={value}
            type="button"
            role="tab"
            aria-selected={role === value}
            onClick={() => setRole(value)}
            className={`rounded-xl px-4 py-2 text-sm font-semibold transition ${
              role === value
                ? 'bg-blue-600 text-white shadow-sm'
                : 'border border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
            }`}
          >
            {TEAM_ROLE_LABELS[value]}
          </button>
        ))}
        </div>
        <div className="text-right text-xs text-slate-500">
          <strong className="block text-sm text-slate-800">{selected.length} enabled</strong>
          {dirty ? 'Unsaved changes' : 'Current permissions'}
        </div>
      </div>

      {!editable ? (
        <p className="rounded-xl border border-amber-200 bg-amber-50 p-3 text-sm text-amber-800">
          Only the business Owner can change role permissions. You can view the effective permissions below.
        </p>
      ) : null}

      <div className="space-y-4">
        {permissionGroups.map((group) => (
          <section key={group.label} className="overflow-hidden rounded-2xl border border-slate-200 bg-white">
            <header className="border-b border-slate-100 bg-slate-50 px-4 py-3">
              <h3 className="text-sm font-bold text-slate-900">{group.label}</h3>
              <p className="mt-0.5 text-xs text-slate-500">{group.description}</p>
            </header>
            <div className="grid gap-0 sm:grid-cols-2">
              {group.permissions.map((permission) => {
                const checked = selectedSet.has(permission);
                return (
                  <label
                    key={permission}
                    className={`flex min-h-12 items-center gap-3 border-b border-slate-100 px-4 py-3 text-sm last:border-b-0 sm:[&:nth-child(odd)]:border-r ${
                      editable ? 'cursor-pointer hover:bg-slate-50' : 'cursor-default'
                    }`}
                  >
                    <input
                      type="checkbox"
                      checked={checked}
                      disabled={!editable || busy}
                      onChange={() => toggle(permission)}
                      className="h-4 w-4 rounded border-slate-300 accent-blue-600"
                    />
                    <span className="min-w-0 flex-1">
                      <span className="block font-semibold text-slate-800">{permissionLabels[permission]}</span>
                      <span className="mt-0.5 block text-xs leading-5 text-slate-500">{permissionDescriptions[permission]}</span>
                    </span>
                    {checked ? <Check size={15} className="shrink-0 text-emerald-600" /> : null}
                  </label>
                );
              })}
            </div>
          </section>
        ))}
      </div>

      {message ? (
        <p
          role={message.error ? 'alert' : 'status'}
          className={`rounded-xl border p-3 text-sm ${
            message.error
              ? 'border-red-200 bg-red-50 text-red-700'
              : 'border-emerald-200 bg-emerald-50 text-emerald-700'
          }`}
        >
          {message.text}
        </p>
      ) : null}

      <div className="rounded-xl border border-amber-200 bg-amber-50 p-3 text-xs leading-5 text-amber-800">
        Changes apply to every user with the selected role in this business. Saving a permission change does not change the Owner account, and users still remain limited to their assigned branch.
      </div>

      <div className="flex flex-wrap items-center justify-between gap-3 border-t border-slate-100 pt-4">
        <p className="text-xs text-slate-500">{dirty ? 'Review the checked features, then save to apply them.' : 'No unsaved permission changes.'}</p>
        <div className="flex flex-wrap gap-2">
        <button
          type="button"
          disabled={!editable || busy}
          onClick={() => void reset()}
          className="inline-flex items-center gap-2 rounded-xl border border-slate-200 px-4 py-2 text-sm font-semibold text-slate-700 disabled:opacity-50"
        >
          <RotateCcw size={15} /> Reset to default
        </button>
        <button
          type="button"
          disabled={!editable || busy || !dirty}
          onClick={() => void save()}
          className="inline-flex items-center gap-2 rounded-xl bg-blue-600 px-4 py-2 text-sm font-semibold text-white disabled:opacity-50"
        >
          <Save size={15} /> {busy ? 'Saving…' : 'Save permissions'}
        </button>
        </div>
      </div>
    </div>
  );
}
