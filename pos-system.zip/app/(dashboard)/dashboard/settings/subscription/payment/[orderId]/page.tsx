import Link from "next/link";
import { notFound } from "next/navigation";
import {
  ArrowLeft,
  CheckCircle2,
  Clock3,
  CreditCard,
  FileCheck2,
  UsersRound,
  XCircle,
} from "lucide-react";

import { getCurrentBusinessForSubscription } from "@/lib/business/get-current-business";
import { supabaseAdmin } from "@/lib/supabase/admin";
import { getSubscriptionPlanLabel } from "@/lib/subscriptions/plans";
import { getManualPaymentConfig } from "@/lib/subscriptions/manual-bank";
import {
  expireSubscriptionPaymentRequestSafely,
  getSubscriptionPaymentExpiryAt,
} from "@/lib/subscriptions/payment-expiry";
import PaymentRequestCountdown from "../../payment-request-countdown";
import CopyPaymentValue from "../../copy-payment-value";
import ExpiredPaymentRedirect from "../../expired-payment-redirect";
import ManualPaymentStatusWatcher from "../../manual-payment-status-watcher";
import ManualPaymentQrPreview from "../../manual-payment-qr-preview";
import {
  cancelPendingSubscriptionPayment,
  selectSubscriptionPaymentMethod,
  submitSubscriptionPayment,
} from "../../actions";

type PaymentMethod = "manual";

type SubscriptionOrder = {
  id: string;
  order_kind: string;
  plan_key: string;
  requested_user_limit: number;
  requested_branch_limit?: number;
  base_plan_key?: string;
  term_months: number;
  monthly_price: number | string | null;
  discount_percent: number | string;
  subtotal_amount: number | string | null;
  term_price_amount: number | string | null;
  remaining_credit_amount: number | string | null;
  total_amount: number | string | null;
  currency: string;
  status: string;
  payment_method: string | null;
  payment_provider?: string | null;
  payway_tran_id?: string | null;
  payway_verified_at?: string | null;
  payway_payment_type?: string | null;
  payment_note: string | null;
  proof_file_name: string | null;
  review_note: string | null;
  pricing_locked_until: string | null;
  payment_expires_at?: string | null;
  payment_expired_at?: string | null;
  manual_payment_reference?: string | null;
  manual_bank_name?: string | null;
  manual_account_name?: string | null;
  manual_account_number?: string | null;
  manual_qr_image_url?: string | null;
  manual_verified_at?: string | null;
  manual_verified_transaction_id?: string | null;
  manual_late_payment_at?: string | null;
  effective_at: string | null;
  activated_at: string | null;
  pricing_version?: number;
  created_at: string;
};

function money(value: number | string | null) {
  if (value === null) return "—";
  return `$${Number(value).toFixed(2)}`;
}

function orderKindLabel(kind: string) {
  switch (kind) {
    case "reactivation":
      return "Reactivation";
    case "upgrade":
      return "Upgrade";
    case "renewal":
      return "Renewal";
    default:
      return "Activation";
  }
}

function statusLabel(order: SubscriptionOrder) {
  if (order.payment_expired_at) return "Payment expired";
  const status = order.status;
  switch (status) {
    case "quote_requested":
      return "Quote requested";
    case "pending_payment":
      return "Payment required";
    case "payment_submitted":
      return "Payment under review";
    case "approved":
      return order.activated_at ? "Subscription activated" : "Payment approved";
    case "rejected":
      return "Payment rejected";
    default:
      return status.replace(/_/g, " ");
  }
}

function paymentMethodLabel(method: PaymentMethod | null, provider?: string | null) {
  if (provider === "aba_payway") return "ABA PayWay";
  if (method === "manual") return "Manual payment";
  return "Choose payment method";
}

export default async function SubscriptionPaymentPage({
  params,
  searchParams,
}: {
  params: Promise<{ orderId: string }>;
  searchParams?: Promise<{ method?: string; switch?: string }>;
}) {
  // Paid checkout must not start a pending free trial implicitly.
  const business = await getCurrentBusinessForSubscription({ startTrial: false });
  const { orderId } = await params;
  const query = searchParams ? await searchParams : {};

  // Server-authoritative expiry. For PayWay this verifies payment first and
  // closes an unpaid transaction before the TENH order is marked expired.
  try {
    await expireSubscriptionPaymentRequestSafely({ businessId: business.id, orderId });
  } catch {
    // Keep the order locked instead of failing the page when an external
    // payment status cannot be resolved safely at this moment.
  }

  const { data, error } = await supabaseAdmin
    .from("subscription_orders")
    .select("*")
    .eq("id", orderId)
    .eq("business_id", business.id)
    .maybeSingle();

  if (error || !data) notFound();
  const order = data as SubscriptionOrder;

  const manualConfig = getManualPaymentConfig();
  const manualBankName = order.manual_bank_name || manualConfig.bankName;
  const manualAccountName = order.manual_account_name || manualConfig.accountName;
  const manualAccountNumber =
    order.manual_account_number || manualConfig.accountNumber;
  const manualQrImageUrl =
    order.manual_qr_image_url === "/images/manual-payment-qr.jpg"
      ? "/manual-payment-qr.jpg"
      : order.manual_qr_image_url || manualConfig.qrImageUrl;
  const manualSnapshotReady = Boolean(
    manualBankName && manualAccountName && manualAccountNumber,
  );
  const manualRouteCommitted = order.payment_method === "manual";
  const manualOptionVisible =
    manualConfig.requestedEnabled ||
    manualConfig.enabled ||
    order.payment_method === "manual";
  const manualOptionAvailable =
    manualConfig.enabled ||
    (order.payment_method === "manual" && manualSnapshotReady);

  const paymentExpired = Boolean(order.payment_expired_at);
  const pending = order.status === "pending_payment" && !paymentExpired;
  const submitted = order.status === "payment_submitted";
  const approved = order.status === "approved";
  const rejected = order.status === "rejected";
  const quoteRequested = order.status === "quote_requested";
  const scheduledForTermEnd =
    order.order_kind === "renewal" &&
    Boolean(order.effective_at) &&
    !order.activated_at;
  const effectiveLabel = order.effective_at
    ? new Intl.DateTimeFormat("en-US", {
        month: "short",
        day: "numeric",
        year: "numeric",
        hour: "numeric",
        minute: "2-digit",
        hour12: true,
        timeZone: "Asia/Phnom_Penh",
      }).format(new Date(order.effective_at))
    : null;
  const priceExpired =
    pending &&
    order.pricing_locked_until !== null &&
    new Date(order.pricing_locked_until).getTime() <= Date.now();
  const paymentExpiresAt = getSubscriptionPaymentExpiryAt(order);
  const paymentRemainingSeconds = paymentExpiresAt
    ? Math.max(0, Math.ceil((new Date(paymentExpiresAt).getTime() - Date.now()) / 1000))
    : 0;
  const creditAmount = Number(order.remaining_credit_amount ?? 0);
  const hasCredit = Number.isFinite(creditAmount) && creditAmount > 0;
  const paymentMethod: PaymentMethod | null =
    manualRouteCommitted ? "manual" : null;
  const paymentProvider = order.payment_provider === "aba_payway" ? "aba_payway" : null;
  const usingPayway = paymentProvider === "aba_payway";
  const paywaySelected =
    pending &&
    !usingPayway &&
    query.method === "payway";
  const manualSelected =
    pending &&
    !usingPayway &&
    !paywaySelected &&
    paymentMethod === "manual";
  const termValue = Number(order.term_price_amount ?? order.total_amount ?? 0);
  const discountedMonthly =
    Number.isFinite(termValue) && termValue > 0 && order.term_months > 0
      ? termValue / order.term_months
      : null;

  return (
    <main className="mx-auto w-full max-w-6xl pb-10">
      <Link
        href="/dashboard/settings/subscription/plans"
        className="inline-flex items-center gap-2 text-sm font-semibold text-slate-500 transition hover:text-blue-600"
      >
        <ArrowLeft size={16} />
        Back to plans
      </Link>

      <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="text-xs font-bold uppercase tracking-[0.18em] text-blue-600">
            Subscription payment
          </p>
          <h1 className="mt-2 text-3xl font-extrabold tracking-tight text-slate-950 dark:text-white">
            {getSubscriptionPlanLabel(order.plan_key)}
          </h1>
          <p className="mt-2 text-sm text-slate-500">
            {orderKindLabel(order.order_kind)} · Order #
            {order.id.slice(0, 8).toUpperCase()} · {order.requested_user_limit}{" "}
            users · {order.requested_branch_limit ?? 1} branches · {order.term_months === 12 ? "1 year" : `${order.term_months} months`}
          </p>
        </div>
        <span
          className={`inline-flex w-fit items-center gap-2 rounded-full px-3 py-1.5 text-xs font-bold ${
            approved
              ? "bg-emerald-50 text-emerald-700"
              : rejected || paymentExpired
                ? "bg-red-50 text-red-700"
                : "bg-amber-50 text-amber-700"
          }`}
        >
          {approved ? (
            <CheckCircle2 size={14} />
          ) : rejected || paymentExpired ? (
            <XCircle size={14} />
          ) : (
            <Clock3 size={14} />
          )}
          {statusLabel(order)}
        </span>
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-[minmax(0,1fr)_420px]">
        <section className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900">
          <h2 className="text-lg font-extrabold text-slate-950 dark:text-white">
            Order summary
          </h2>
          <div className="mt-5 divide-y divide-slate-100 rounded-2xl border border-slate-200 dark:divide-slate-800 dark:border-slate-700">
            <Row label="Flow" value={orderKindLabel(order.order_kind)} />
            {scheduledForTermEnd && effectiveLabel ? <Row label="Applies" value={effectiveLabel} /> : null}
            <Row label="Plan" value={getSubscriptionPlanLabel(order.plan_key)} />
            <Row
              label="Users"
              value={`${order.requested_user_limit}`}
              icon={<UsersRound size={17} />}
            />
            <Row
              label="Term"
              value={
                order.term_months === 12
                  ? "1 year"
                  : `${order.term_months} months`
              }
            />
            <Row label="Regular monthly rate" value={money(order.monthly_price)} />
            {discountedMonthly !== null ? (
              <Row
                label="Discounted monthly rate"
                value={`$${discountedMonthly.toFixed(2)}`}
              />
            ) : null}
            <Row label="Subtotal" value={money(order.subtotal_amount)} />
            <Row
              label="Term discount"
              value={`${Number(order.discount_percent).toFixed(0)}%`}
            />
            <Row
              label="Discounted term total"
              value={money(order.term_price_amount ?? order.total_amount)}
            />
            {hasCredit ? (
              <Row
                label="Current subscription credit"
                value={`-${money(creditAmount)}`}
              />
            ) : null}
            {paymentMethod || usingPayway || paywaySelected ? (
              <Row
                label="Payment method"
                value={paywaySelected ? "ABA PayWay" : paymentMethodLabel(paymentMethod, paymentProvider)}
              />
            ) : null}
          </div>

          <div className="mt-5 flex items-center justify-between rounded-2xl bg-slate-950 px-5 py-4 text-white">
            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.14em] text-slate-400">
                One-time payment
              </p>
              <p className="mt-1 text-sm text-slate-300">Exact amount · USD</p>
            </div>
            <p className="text-3xl font-black">{money(order.total_amount)}</p>
          </div>

          {scheduledForTermEnd && effectiveLabel ? (
            <div className="mt-5 rounded-2xl border border-blue-200 bg-blue-50 p-4 text-sm leading-6 text-blue-900 dark:border-blue-900 dark:bg-blue-950/30 dark:text-blue-200">
              Your current paid access stays unchanged until {effectiveLabel}. The selected plan applies then. If the selected limits are lower than current usage, excess users and branches are disabled, never deleted. Owner and Main Branch stay protected.
            </div>
          ) : null}

          {rejected && order.review_note ? (
            <div className="mt-5 rounded-2xl border border-red-200 bg-red-50 p-4 text-sm font-semibold leading-6 text-red-800">
              {order.review_note}
            </div>
          ) : null}
        </section>

        <aside className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900">
          <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-blue-50 text-blue-600">
            <CreditCard size={22} />
          </div>
          <h2 className="mt-4 text-xl font-extrabold text-slate-950 dark:text-white">
            {paywaySelected
              ? "ABA PayWay"
              : paymentMethodLabel(paymentMethod, paymentProvider)}
          </h2>

          {quoteRequested ? (
            <div className="mt-4 rounded-2xl border border-blue-200 bg-blue-50 p-4 text-sm leading-6 text-blue-900">
              TENH is preparing the custom monthly quote. Return to this page after
              the quote is created to choose ABA PayWay or Manual payment.
            </div>
          ) : approved ? (
            <div className="mt-4 rounded-2xl border border-emerald-200 bg-emerald-50 p-4 text-sm leading-6 text-emerald-800">
              {scheduledForTermEnd && effectiveLabel
                ? `Payment verified. Your current paid access stays unchanged until ${effectiveLabel}; the selected plan applies then.`
                : !order.activated_at
                  ? "Payment verified. TENH is applying the selected subscription safely; no second payment is needed."
                  : "Payment verified. Your subscription is active and the selected plan entitlements are applied."}
            </div>
          ) : submitted ? (
            <>
              <div className="mt-4 rounded-2xl border border-amber-200 bg-amber-50 p-4 text-sm leading-6 text-amber-900">
                {scheduledForTermEnd && effectiveLabel
                  ? `Payment proof submitted. Our team will verify it. If approved, your current paid access stays unchanged until ${effectiveLabel}.`
                  : "Payment proof submitted. Our team will verify it before activating the subscription."}
              </div>
              <div className="mt-4 text-sm leading-6 text-slate-600 dark:text-slate-300">
                <p className="font-bold text-slate-900 dark:text-white">Taking longer than expected?</p>
                <p>
                  Contact{" "}
                  <a
                    href="https://t.me/tenhchat_support_bot"
                    target="_blank"
                    rel="noreferrer"
                    className="font-semibold text-blue-600 hover:underline dark:text-blue-400"
                  >
                    TENH Support
                  </a>{" "}
                  for assistance with your payment verification.
                </p>
              </div>
            </>
          ) : paymentExpired ? (
            <div className="mt-4 rounded-2xl border border-red-200 bg-red-50 p-4 text-sm leading-6 text-red-800 dark:border-red-900 dark:bg-red-950/30 dark:text-red-200">
              <p className="font-bold">Payment request expired</p>
              {order.payment_expired_at ? (
                <ExpiredPaymentRedirect expiredAt={order.payment_expired_at} />
              ) : null}
              <Link
                href="/dashboard/settings/subscription/plans"
                className="mt-3 inline-flex rounded-xl bg-blue-600 px-4 py-2.5 font-bold text-white hover:bg-blue-700"
              >
                Choose Subscription
              </Link>
            </div>
          ) : rejected ? (
            <div className="mt-4 rounded-2xl border border-red-200 bg-red-50 p-4 text-sm leading-6 text-red-800">
              This payment was rejected. Create a new subscription order after
              correcting the payment.
            </div>
          ) : pending && priceExpired ? (
            <div className="mt-4 rounded-2xl border border-amber-200 bg-amber-50 p-4 text-sm leading-6 text-amber-900">
              This price lock expired before payment was submitted. Return to
              Subscription and create a fresh order.
              <Link
                href="/dashboard/settings/subscription/plans"
                className="mt-3 inline-flex font-bold text-blue-700 hover:text-blue-800"
              >
                Create fresh subscription order
              </Link>
            </div>
          ) : pending ? (
            <>
              <p className="mt-3 text-sm leading-6 text-slate-500">
                Choose how you want to pay. You can switch methods while this
                order is still waiting for payment.
              </p>

              {paymentExpiresAt ? (
                <PaymentRequestCountdown
                  orderId={order.id}
                  expiresAt={paymentExpiresAt}
                  initialRemainingSeconds={paymentRemainingSeconds}
                  variant="panel"
                />
              ) : null}

              {query.switch === "payway_close_unavailable" ? (
                <div className="mt-3 rounded-2xl border border-amber-200 bg-amber-50 p-4 text-sm leading-6 text-amber-900 dark:border-amber-900 dark:bg-amber-950/30 dark:text-amber-200">
                  ABA PayWay could not safely close the current transaction yet. TENH kept it locked to prevent duplicate payment. Check payment status or try switching again later.
                </div>
              ) : query.switch === "payway_status_unavailable" ? (
                <div className="mt-3 rounded-2xl border border-amber-200 bg-amber-50 p-4 text-sm leading-6 text-amber-900 dark:border-amber-900 dark:bg-amber-950/30 dark:text-amber-200">
                  TENH could not confirm the ABA PayWay status right now. No payment method was changed.
                </div>
              ) : null}

              {usingPayway ? (
                <div className="mt-4 rounded-2xl border border-blue-200 bg-blue-50 p-4 dark:border-blue-900 dark:bg-blue-950/30">
                  <p className="text-sm font-bold text-blue-900 dark:text-blue-200">
                    ABA PayWay checkout started
                  </p>
                  <p className="mt-1 text-xs leading-5 text-blue-700 dark:text-blue-300">
                    This order is locked to one PayWay transaction to prevent duplicate charges. Check its status before doing anything else.
                  </p>
                  <div className={`mt-3 grid gap-2 ${manualOptionAvailable ? "sm:grid-cols-3" : "sm:grid-cols-2"}`}>
                    <Link
                      href={`/dashboard/settings/subscription/payment/${order.id}/payway-return`}
                      className="inline-flex items-center justify-center rounded-xl bg-blue-600 px-4 py-2.5 text-sm font-bold text-white hover:bg-blue-700"
                    >
                      Check payment status
                    </Link>
                    {manualOptionAvailable ? (
                      <form action={selectSubscriptionPaymentMethod}>
                        <input type="hidden" name="orderId" value={order.id} />
                        <input type="hidden" name="paymentMethod" value="manual" />
                        <button
                          type="submit"
                          className="inline-flex w-full items-center justify-center rounded-xl border border-blue-200 bg-white px-4 py-2.5 text-sm font-bold text-blue-700 hover:bg-blue-50 dark:border-blue-800 dark:bg-slate-900 dark:text-blue-300"
                        >
                          Switch to Manual
                        </button>
                      </form>
                    ) : null}
                    <form action={cancelPendingSubscriptionPayment}>
                      <input type="hidden" name="orderId" value={order.id} />
                      <button
                        type="submit"
                        className="inline-flex w-full items-center justify-center rounded-xl border border-blue-200 bg-white px-4 py-2.5 text-sm font-bold text-blue-700 hover:bg-blue-50 dark:border-blue-800 dark:bg-slate-900 dark:text-blue-300"
                      >
                        Cancel pending payment
                      </button>
                    </form>
                  </div>
                </div>
              ) : (
                <>
                  <div className={`mt-4 grid gap-3 ${manualOptionVisible ? "sm:grid-cols-2" : "sm:grid-cols-1"}`}>
                    <PaywayMethodButton
                      orderId={order.id}
                      active={paywaySelected}
                      disabled={false}
                    />
                    {manualOptionVisible ? (
                      <PaymentMethodButton
                        orderId={order.id}
                        method="manual"
                        active={manualSelected}
                        title="Manual"
                        description={manualOptionAvailable ? "Bank transfer" : "Check Manual payment setup"}
                        icon={<CreditCard size={21} />}
                        disabled={!manualOptionAvailable}
                      />
                    ) : null}
                  </div>

                  {manualConfig.requestedEnabled && !manualConfig.enabled ? (
                    <div className="mt-3 rounded-xl border border-amber-200 bg-amber-50 px-3.5 py-3 text-xs leading-5 text-amber-800 dark:border-amber-900 dark:bg-amber-950/30 dark:text-amber-200">
                      Manual payment is enabled, but the bank setup is incomplete. Check TENH_MANUAL_PAYMENT_BANK_NAME, TENH_MANUAL_PAYMENT_ACCOUNT_NAME, and TENH_MANUAL_PAYMENT_ACCOUNT_NUMBER, then restart the app.
                    </div>
                  ) : null}
                </>
              )}

              {!usingPayway && paywaySelected ? (
                <div className="mt-5 rounded-2xl border border-blue-200 bg-blue-50 p-4 dark:border-blue-900 dark:bg-blue-950/30">
                  <p className="text-sm font-extrabold text-blue-900 dark:text-blue-200">
                    ABA PayWay selected
                  </p>
                  <p className="mt-1 text-xs leading-5 text-blue-700 dark:text-blue-300">
                    Review the order amount, then click Pay with ABA PayWay.
                  </p>
                  <Link
                    href={`/dashboard/settings/subscription/payment/${order.id}/payway`}
                    className="mt-3 inline-flex w-full items-center justify-center rounded-xl bg-blue-600 px-4 py-3 text-sm font-bold text-white transition hover:bg-blue-700"
                  >
                    Pay with ABA PayWay
                  </Link>
                </div>
              ) : null}

              {!usingPayway && manualSelected ? (
                <>
                  <ManualPaymentStatusWatcher />
                  <div className="mt-5 rounded-2xl border border-slate-200 bg-slate-50 p-4 dark:border-slate-700 dark:bg-slate-950">
                    <div>
                        <p className="text-sm font-extrabold text-slate-900 dark:text-white">
                          Manual Bank Transfer
                        </p>
                        <p className="mt-1 text-xs leading-5 text-slate-500 dark:text-slate-400">
                          Your payment will be manually verified by <strong className="font-bold text-slate-700 dark:text-slate-300">TENH</strong>. This process usually takes <strong className="font-bold text-slate-700 dark:text-slate-300">1–2 business days</strong>.
                        </p>
                      </div>

                    <div className="mt-4 rounded-2xl border border-slate-200 bg-white p-4 dark:border-slate-700 dark:bg-slate-900">
                      {manualQrImageUrl ? (
                        <div className="mb-4 flex justify-center">
                          <ManualPaymentQrPreview imageUrl={manualQrImageUrl} />
                        </div>
                      ) : null}

                      <ManualPaymentRow label="Bank" value={manualBankName || "—"} />
                      <ManualPaymentRow
                        label="Account name"
                        value={manualAccountName || "—"}
                      />
                      <ManualPaymentRow
                        label="Account number"
                        value={manualAccountNumber || "—"}
                        copyValue={manualAccountNumber || undefined}
                      />
                      <ManualPaymentRow
                        label="Amount"
                        value={`${money(order.total_amount)} ${order.currency || "USD"}`}
                        copyValue={Number(order.total_amount ?? 0).toFixed(2)}
                      />
                    </div>
                  </div>
                  <PaymentProofForm order={order} method="manual" />
                </>
              ) : !paywaySelected && !manualSelected ? (
                <div className="mt-5 rounded-2xl border border-dashed border-slate-300 p-5 text-center text-sm font-semibold text-slate-500 dark:border-slate-700">
                  Select ABA PayWay or Manual payment to continue.
                </div>
              ) : null}

              {!usingPayway ? (
                <div className="mt-4 rounded-2xl border border-slate-200 bg-white p-4 dark:border-slate-700 dark:bg-slate-900">
                  <p className="text-xs leading-5 text-slate-500 dark:text-slate-400">
                    Changed your mind? You can cancel this transaction.
                  </p>
                  <form action={cancelPendingSubscriptionPayment} className="mt-3">
                    <input type="hidden" name="orderId" value={order.id} />
                    <button
                      type="submit"
                      className="inline-flex w-full items-center justify-center rounded-xl border border-red-200 bg-white px-4 py-2.5 text-sm font-bold text-red-600 transition hover:bg-red-50 dark:border-red-900 dark:bg-slate-900 dark:text-red-300 dark:hover:bg-red-950/30"
                    >
                      Cancel pending payment
                    </button>
                  </form>
                </div>
              ) : null}

            </>
          ) : null}
        </aside>
      </div>
    </main>
  );
}


function PaywayMethodButton({
  orderId,
  active,
  disabled,
}: {
  orderId: string;
  active: boolean;
  disabled: boolean;
}) {
  const className = `flex min-h-[108px] w-full items-center rounded-2xl border p-4 text-left transition ${
    active
      ? "border-blue-500 bg-blue-50 text-blue-700 ring-1 ring-blue-500 dark:bg-blue-950/30 dark:text-blue-300"
      : disabled
        ? "cursor-not-allowed border-slate-200 bg-slate-50 text-slate-400 opacity-70 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-500"
        : "border-slate-200 bg-white text-slate-700 hover:border-blue-300 hover:bg-blue-50/50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200"
  }`;

  const content = (
      <span className="flex items-center gap-3 text-sm font-extrabold">
        <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-slate-50 dark:bg-slate-800">
          {/* aba-khqr.png is the existing ABA brand image in /public. */}
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src="/aba-khqr.png"
            alt="ABA PayWay"
            className="h-9 w-9 rounded-lg object-contain"
          />
        </span>
        <span>
          <span className="block">ABA PayWay</span>
          <span className="mt-0.5 block text-xs font-medium opacity-75">
            Secure online checkout
          </span>
        </span>
      </span>
  );

  if (disabled) {
    return (
      <div className={className} aria-disabled="true" title="ABA PayWay is not available for this payment state.">
        {content}
      </div>
    );
  }

  return (
    <Link
      href={`/dashboard/settings/subscription/payment/${orderId}?method=payway`}
      className={className}
    >
      {content}
    </Link>
  );
}

function PaymentMethodButton({
  orderId,
  method,
  active,
  title,
  description,
  icon,
  disabled = false,
}: {
  orderId: string;
  method: PaymentMethod;
  active: boolean;
  title: string;
  description: string;
  icon: React.ReactNode;
  disabled?: boolean;
}) {
  return (
    <form action={selectSubscriptionPaymentMethod} className="h-full">
      <input type="hidden" name="orderId" value={orderId} />
      <input type="hidden" name="paymentMethod" value={method} />
      <button
        type="submit"
        disabled={disabled}
        className={`flex min-h-[108px] w-full items-center rounded-2xl border p-4 text-left transition disabled:cursor-not-allowed disabled:opacity-60 ${
          active
            ? "border-blue-500 bg-blue-50 text-blue-700 ring-1 ring-blue-500 dark:bg-blue-950/30 dark:text-blue-300"
            : "border-slate-200 bg-white text-slate-700 hover:border-blue-300 hover:bg-blue-50/50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200"
        }`}
      >
        <span className="flex items-center gap-3">
          <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-slate-50 dark:bg-slate-800">
            {icon}
          </span>
          <span>
            <span className="block text-sm font-extrabold">{title}</span>
            <span className="mt-0.5 block text-xs font-medium opacity-75">{description}</span>
          </span>
        </span>
      </button>
    </form>
  );
}

function ManualPaymentRow({
  label,
  value,
  copyValue,
  helperText,
  highlight = false,
}: {
  label: string;
  value: string;
  copyValue?: string;
  helperText?: string;
  highlight?: boolean;
}) {
  return (
    <div className="flex items-center justify-between gap-3 border-b border-slate-100 py-3 last:border-b-0 dark:border-slate-800">
      <div className="min-w-0">
        <p className="text-[11px] font-bold uppercase tracking-wide text-slate-400">
          {label}
        </p>
        <p
          className={`mt-1 break-all font-bold ${
            highlight
              ? "text-lg tracking-wide text-blue-600"
              : "text-sm text-slate-900 dark:text-white"
          }`}
        >
          {value}
        </p>
        {helperText ? (
          <p className="mt-1.5 max-w-md text-xs font-medium leading-5 text-slate-500 dark:text-slate-400">
            {helperText}
          </p>
        ) : null}
      </div>
      {copyValue ? <CopyPaymentValue value={copyValue} /> : null}
    </div>
  );
}

function PaymentProofForm({
  order,
  method,
}: {
  order: SubscriptionOrder;
  method: PaymentMethod;
}) {
  return (
    <form action={submitSubscriptionPayment} className="mt-5 space-y-4">
      <input type="hidden" name="orderId" value={order.id} />

      <div>
        <label
          htmlFor={`paymentProof-${method}`}
          className="block text-sm font-semibold text-slate-700 dark:text-slate-300"
        >
          Payment proof *
        </label>
        <input
          id={`paymentProof-${method}`}
          name="paymentProof"
          type="file"
          accept="image/jpeg,image/png,image/webp,application/pdf"
          required={!order.proof_file_name}
          className="mt-2 block w-full rounded-xl border border-slate-300 bg-white px-3 py-2.5 text-sm dark:border-slate-700 dark:bg-slate-950"
        />
        <p className="mt-1 text-xs text-slate-400">
          JPG, PNG, WEBP, or PDF · max 10 MB
        </p>
      </div>

      <div>
        <label
          htmlFor={`paymentNote-${method}`}
          className="block text-sm font-semibold text-slate-700 dark:text-slate-300"
        >
          Additional note (optional)
        </label>
        <textarea
          id={`paymentNote-${method}`}
          name="paymentNote"
          maxLength={1000}
          rows={3}
          defaultValue={order.payment_note ?? ""}
          placeholder="Optional: transfer details for the TENH team"
          className="mt-2 w-full resize-none rounded-xl border border-slate-300 bg-white px-3.5 py-3 text-sm outline-none focus:border-blue-500 focus:ring-4 focus:ring-blue-100 dark:border-slate-700 dark:bg-slate-950 dark:text-white"
        />
      </div>
      <button
        type="submit"
        className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-blue-600 px-4 py-3 text-sm font-bold text-white transition hover:bg-blue-700"
      >
        <FileCheck2 size={17} />
        Submit proof for manual review
      </button>
    </form>
  );
}

function Row({
  label,
  value,
  icon,
}: {
  label: string;
  value: string;
  icon?: React.ReactNode;
}) {
  return (
    <div className="flex items-center justify-between gap-4 px-4 py-3.5 text-sm">
      <span className="text-slate-500">{label}</span>
      <span className="flex items-center gap-2 font-bold text-slate-900 dark:text-white">
        {icon}
        {value}
      </span>
    </div>
  );
}
