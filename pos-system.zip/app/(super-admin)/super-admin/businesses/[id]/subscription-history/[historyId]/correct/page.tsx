import Link from "next/link";
import {
  notFound,
} from "next/navigation";



import {
  requireSuperAdmin,
} from "@/lib/auth/require-super-admin";
import {
  supabaseAdmin,
} from "@/lib/supabase/admin";

import {
  correctSubscriptionExtension,
} from "./actions";

type PageProps = {
  params: Promise<{
    id: string;
    historyId: string;
  }>;
};

export default async function CorrectExtensionPage({
  params,
}: PageProps) {
  await requireSuperAdmin();

  const { id, historyId } =
    await params;

  const {
    data: history,
    error,
  } = await supabaseAdmin
    .from("subscription_history")
    .select(`
      id,
      business_id,
      action,
      months,
      previous_expiry,
      new_expiry,
      created_at
    `)
    .eq("id", historyId)
    .eq("business_id", id)
    .maybeSingle();

  if (
    error ||
    !history ||
    history.action !== "extended"
  ) {
    notFound();
  }

  return (
    <main className="min-h-screen bg-slate-100 p-6">
      <div className="mx-auto max-w-2xl space-y-6">
        <Link
          href={`/super-admin/businesses/${id}`}
          className="text-sm font-semibold text-blue-600 hover:underline"
        >
          ← Back to Business
        </Link>

        <section className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
          <h1 className="text-2xl font-bold text-slate-900">
            Correct Subscription Extension
          </h1>

          <p className="mt-2 text-sm text-slate-500">
            Replace the original extension with the correct number of months.
          </p>

          <div className="mt-6 rounded-xl bg-slate-50 p-4 text-sm">
            <p>
              <span className="font-semibold">
                Original extension:
              </span>{" "}
              {history.months} month
              {history.months === 1
                ? ""
                : "s"}
            </p>

            <p className="mt-2">
              <span className="font-semibold">
                Previous expiry:
              </span>{" "}
              {history.previous_expiry
                ? new Date(
                    history.previous_expiry,
                  ).toLocaleDateString(
                    "en-GB",
                  )
                : "—"}
            </p>

            <p className="mt-2">
              <span className="font-semibold">
                Resulting expiry:
              </span>{" "}
              {new Date(
                history.new_expiry,
              ).toLocaleDateString(
                "en-GB",
              )}
            </p>
          </div>

          <form
            action={
              correctSubscriptionExtension
            }
            className="mt-6 space-y-5"
          >
            <input
              type="hidden"
              name="businessId"
              value={id}
            />

            <input
              type="hidden"
              name="historyId"
              value={history.id}
            />

            <div>
              <label className="text-sm font-semibold text-slate-700">
                Correct extension
              </label>

              <select
                name="months"
                defaultValue=""
                required
                className="mt-2 w-full rounded-xl border border-slate-300 bg-white px-4 py-3 outline-none focus:border-blue-500"
              >
                <option value="" disabled>
                  Select months
                </option>

                {[1, 3, 5, 12].map(
                  (months) => (
                    <option
                      key={months}
                      value={months}
                    >
                      {months} Month
                      {months === 1
                        ? ""
                        : "s"}
                    </option>
                  ),
                )}
              </select>
            </div>

            <div>
              <label className="text-sm font-semibold text-slate-700">
                Correction reason
              </label>

              <textarea
                name="reason"
                required
                rows={4}
                placeholder="Example: Customer requested 5 months, but 12 months was selected accidentally."
                className="mt-2 w-full resize-none rounded-xl border border-slate-300 px-4 py-3 outline-none focus:border-blue-500"
              />
            </div>

            <button
              type="submit"
              className="w-full rounded-xl bg-blue-600 px-4 py-3 font-semibold text-white transition hover:bg-blue-700"
            >
              Save Correction
            </button>
          </form>
        </section>
      </div>
    </main>
  );
}