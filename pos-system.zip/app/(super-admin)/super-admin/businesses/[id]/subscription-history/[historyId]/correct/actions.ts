"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { createBusinessHistory } from "@/lib/business/create-business-history";
import { requireSuperAdmin } from "@/lib/auth/require-super-admin";
import { supabaseAdmin } from "@/lib/supabase/admin";

const validMonths = [1, 3, 5, 12] as const;

function getRequiredText(
  formData: FormData,
  key: string,
): string {
  const value = formData.get(key);

  if (
    typeof value !== "string" ||
    !value.trim()
  ) {
    throw new Error(
      `${key} is required.`,
    );
  }

  return value.trim();
}

export async function correctSubscriptionExtension(
  formData: FormData,
) {
  const superAdmin =
    await requireSuperAdmin();

  const businessId = getRequiredText(
    formData,
    "businessId",
  );

  const historyId = getRequiredText(
    formData,
    "historyId",
  );

  const reason = getRequiredText(
    formData,
    "reason",
  );

  const months = Number(
    formData.get("months"),
  );

  if (
    !Number.isInteger(months) ||
    !validMonths.includes(
      months as (typeof validMonths)[number],
    )
  ) {
    throw new Error(
      "Select 1, 3, 5, or 12 months.",
    );
  }

  const {
    data: correctedExpiry,
    error,
  } = await supabaseAdmin.rpc(
    "correct_subscription_extension",
    {
      p_business_id: businessId,
      p_history_id: historyId,
      p_months: months,
      p_reason: reason,
      p_created_by: superAdmin.id,
    },
  );

  if (error) {
    throw new Error(error.message);
  }

  if (!correctedExpiry) {
    throw new Error(
      "The corrected expiry date was not returned.",
    );
  }

  revalidatePath(
    `/super-admin/businesses/${businessId}`,
  );

  redirect(
    `/super-admin/businesses/${businessId}`,
  );
}
