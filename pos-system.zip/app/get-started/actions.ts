"use server";

import {
  getBusinessModeDefaults,
  getBusinessModePreset,
} from "@/lib/business/business-mode-presets";
import { createClient } from "@/lib/supabase/server";
import { supabaseAdmin } from "@/lib/supabase/admin";
import { getTenantDashboardUrl } from "@/lib/tenancy/domain";
import { getStoreSlugAvailability } from "@/lib/tenancy/store-slug-availability";

import type { GetStartedState } from "./state";


export type GetStartedStoreAddressAvailabilityResult = {
  slug: string;
  available: boolean;
  status: "available" | "invalid" | "taken" | "error";
  message: string;
};

export async function checkGetStartedStoreAddressAvailability(
  rawSubdomain: string,
): Promise<GetStartedStoreAddressAvailabilityResult> {
  const supabase = await createClient();
  const {
    data: { user },
    error: userError,
  } = await supabase.auth.getUser();

  if (userError || !user) {
    return {
      slug: "",
      available: false,
      status: "error",
      message: "Sign in before checking a TENH POS store address.",
    };
  }

  try {
    const availability = await getStoreSlugAvailability(rawSubdomain);

    if (availability.status === "invalid" || availability.status === "reserved") {
      return {
        slug: availability.slug,
        available: false,
        status: "invalid",
        message:
          "Use 2–40 lowercase letters, numbers or hyphens. Reserved TENH addresses cannot be used.",
      };
    }

    if (availability.status === "already_taken") {
      return {
        slug: availability.slug,
        available: false,
        status: "taken",
        message: "This TENH POS address is already in use. Try another one.",
      };
    }

    return {
      slug: availability.slug,
      available: true,
      status: "available",
      message: "Available — you can use this TENH POS store address.",
    };
  } catch {
    return {
      slug: "",
      available: false,
      status: "error",
      message: "TENH could not check this address right now. Please try again.",
    };
  }
}

function requiredText(formData: FormData, key: string) {
  const value = formData.get(key);

  if (typeof value !== "string" || !value.trim()) {
    throw new Error(`${key} is required.`);
  }

  return value.trim();
}

function cleanupMessage(error: unknown) {
  if (error instanceof Error) {
    return error.message;
  }

  return "Unable to create your Tenh POS business.";
}

export async function createOwnerBusiness(
  _previousState: GetStartedState,
  formData: FormData,
): Promise<GetStartedState> {
  let createdBusinessId: string | null = null;

  try {
    const supabase = await createClient();
    const {
      data: { user },
      error: userError,
    } = await supabase.auth.getUser();

    if (userError || !user) {
      return {
        success: false,
        message: "Sign in before setting up your business.",
      };
    }

    const {
      data: profile,
      error: profileError,
    } = await supabaseAdmin
      .from("profiles")
      .select("id, full_name, email, role, is_active")
      .eq("id", user.id)
      .maybeSingle();

    if (profileError) {
      throw new Error(
        `Unable to load your account: ${profileError.message}`,
      );
    }

    if (!profile || profile.is_active !== true) {
      return {
        success: false,
        message: "Your Tenh POS account is not active.",
      };
    }

    // Do not create a second business if another tab/request completed setup.
    const {
      data: existingMembership,
      error: membershipLookupError,
    } = await supabaseAdmin
      .from("business_members")
      .select("business_id")
      .eq("user_id", user.id)
      .eq("is_active", true)
      .limit(1)
      .maybeSingle();

    if (membershipLookupError) {
      throw new Error(
        `Unable to check your business access: ${membershipLookupError.message}`,
      );
    }

    if (existingMembership) {
      const { data: existingBusiness } = await supabaseAdmin
        .from("businesses")
        .select("slug")
        .eq("id", existingMembership.business_id)
        .maybeSingle();

      if (existingBusiness?.slug) {
        return {
          success: true,
          message: "Your business is already set up.",
          destination: getTenantDashboardUrl(
            existingBusiness.slug,
            "/dashboard",
          ),
        };
      }

      return {
        success: false,
        message: "Your account already belongs to a business.",
      };
    }

    const selectedMode = requiredText(formData, "businessMode");
    const preset = getBusinessModePreset(selectedMode);

    if (!preset) {
      return {
        success: false,
        message: "Choose a valid business type.",
      };
    }

    const businessName = requiredText(formData, "businessName");
    const requestedSlug = requiredText(formData, "subdomain");

    if (businessName.length < 2 || businessName.length > 100) {
      return {
        success: false,
        message: "Business name must be between 2 and 100 characters.",
      };
    }

    const slugAvailability = await getStoreSlugAvailability(requestedSlug);
    const slug = slugAvailability.slug;

    if (
      slugAvailability.status === "invalid" ||
      slugAvailability.status === "reserved"
    ) {
      return {
        success: false,
        message:
          "Choose a store address using 2–40 lowercase letters, numbers or hyphens.",
      };
    }

    if (slugAvailability.status === "already_taken") {
      return {
        success: false,
        message: "This Tenh POS store address is already in use.",
      };
    }

    const {
      data: business,
      error: businessError,
    } = await supabaseAdmin
      .from("businesses")
      .insert({
        name: businessName,
        slug,
        owner_id: user.id,
        product_mode: preset.productMode,
        max_staff: 3,
        // New owner-created businesses start in a locked onboarding state.
        // The owner can explicitly start the protected 7-day free trial or
        // choose a paid plan before entering the normal dashboard.
        subscription_plan_key: "trial",
        subscription_months: null,
        subscription_started_at: null,
        subscription_expires_at: null,
        subscription_status: "trial_pending",
        trial_started_at: null,
        trial_expires_at: null,
        expired_at: null,
        deletion_scheduled_at: null,
        trial_block_reason: null,
        is_active: true,
        disabled_at: null,
        disabled_reason: null,
      })
      .select("id")
      .single();

    if (businessError || !business) {
      if (businessError?.code === "23505") {
        return {
          success: false,
          message:
            "This TENH POS store address was just claimed. Choose another address and check availability again.",
        };
      }

      throw new Error(
        businessError?.message ?? "Unable to create your business workspace.",
      );
    }

    createdBusinessId = business.id;

    const { error: membershipError } = await supabaseAdmin
      .from("business_members")
      .insert({
        business_id: createdBusinessId,
        user_id: user.id,
        role: "owner",
        is_active: true,
      });

    if (membershipError) {
      throw new Error(
        `Unable to create owner access: ${membershipError.message}`,
      );
    }

    const { error: ownerProfileError } = await supabaseAdmin
      .from("profiles")
      .update({
        role: "owner",
        is_active: true,
      })
      .eq("id", user.id);

    if (ownerProfileError) {
      throw new Error(
        `Unable to update owner profile: ${ownerProfileError.message}`,
      );
    }

    const storefrontDefaults = getBusinessModeDefaults(preset.value);

    const { error: storefrontError } = await supabaseAdmin
      .from("business_storefronts")
      .upsert(
        {
          business_id: createdBusinessId,
          business_type: preset.value,
          display_name: businessName,
          allow_pickup: storefrontDefaults.allowPickup,
          allow_delivery: storefrontDefaults.allowDelivery,
          allow_dine_in: storefrontDefaults.allowDineIn,
          updated_at: new Date().toISOString(),
        },
        { onConflict: "business_id" },
      );

    if (storefrontError) {
      throw new Error(
        `Unable to configure online store: ${storefrontError.message}`,
      );
    }

    const {
      data: mainBranch,
      error: locationError,
    } = await supabaseAdmin
      .from("business_locations")
      .insert({
        business_id: createdBusinessId,
        name: "Main Branch",
        code: "MAIN",
        is_default: true,
        is_active: true,
      })
      .select("id")
      .single();

    if (locationError || !mainBranch) {
      throw new Error(
        locationError?.message ?? "Unable to create the default branch.",
      );
    }

    const { error: defaultLocationError } = await supabaseAdmin
      .from("business_members")
      .update({ default_location_id: mainBranch.id })
      .eq("business_id", createdBusinessId)
      .eq("user_id", user.id);

    if (defaultLocationError) {
      throw new Error(
        `Unable to set your default branch: ${defaultLocationError.message}`,
      );
    }

    return {
      success: true,
      message: "Your Tenh POS business is ready. Choose a subscription or continue with the 7-day free trial.",
      destination: getTenantDashboardUrl(
        slug,
        "/dashboard/settings/subscription/plans?onboarding=1",
      ),
    };
  } catch (error) {
    // Keep the account. Only remove the partially-created business workspace.
    if (createdBusinessId) {
      await supabaseAdmin
        .from("businesses")
        .delete()
        .eq("id", createdBusinessId);
    }

    return {
      success: false,
      message: cleanupMessage(error),
    };
  }
}
