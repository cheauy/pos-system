import "server-only";

import { cache } from "react";
import { supabaseAdmin } from "@/lib/supabase/admin";
import type { BusinessRole, CurrentBusiness } from "@/lib/business/types";
import {
  permissions,
  rolePermissions,
  type Permission,
} from "@/lib/auth/permissions";

const known = new Set<string>(permissions);

function fallback(role: BusinessRole): Permission[] {
  return [...(rolePermissions[role] ?? [])];
}

export const getEffectivePermissions = cache(
  async (businessId: string, role: BusinessRole): Promise<Permission[]> => {
    if (role === "owner") return [...permissions];
    if (role === "admin") return fallback(role);

    const { data, error } = await supabaseAdmin
      .from("business_role_permissions")
      .select("permission,enabled")
      .eq("business_id", businessId)
      .eq("role", role);

    // Older databases fall back to the existing role defaults until the
    // migration is applied. Access never expands beyond the old defaults.
    if (error) {
      if (["42P01", "42703", "PGRST204", "PGRST205"].includes(error.code ?? "")) {
        return fallback(role);
      }
      throw new Error(`Unable to load role permissions: ${error.message}`);
    }

    if (!data?.length) return fallback(role);

    const overrides = new Map<string, boolean>();
    for (const row of data) {
      if (known.has(row.permission)) overrides.set(row.permission, row.enabled === true);
    }

    return permissions.filter((permission) =>
      overrides.has(permission)
        ? overrides.get(permission) === true
        : rolePermissions[role]?.includes(permission) === true,
    );
  },
);

export async function businessHasPermission(
  business: Pick<CurrentBusiness, "id" | "role">,
  permission: Permission,
) {
  const effective = await getEffectivePermissions(business.id, business.role);
  return effective.includes(permission);
}

export async function getPermissionMatrix(businessId: string) {
  const result = {} as Record<BusinessRole, Permission[]>;
  for (const role of ["owner", "admin", "manager", "staff", "cashier"] as BusinessRole[]) {
    result[role] = await getEffectivePermissions(businessId, role);
  }
  return result;
}
